import React, { useState, useEffect } from 'react'
import { Container, Row, Modal, Button } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";
import ReactPaginate from "react-paginate";
import { CButton, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from '@coreui/react';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import swal from 'sweetalert';
import Multiselect from 'multiselect-react-dropdown';
import DatePicker from "react-datepicker";  //https://www.npmjs.com/package/react-datepicker
import "react-datepicker/dist/react-datepicker.css";

const Maternitycondition = () => {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [perPage] = useState(10);
    const [pageCount, setPageCount] = useState(0);
    const [page, setPage] = useState(1);
    const [excelfile, setExcelfile] = useState("");
    const [usertype, setUsertype] = useState('');
    const [usertype_status, setUsertypestatus] = useState('');
    const [id, setId] = useState('');
    const [visible, setVisible] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [visibleedit, setVisibleedit] = useState(false);
    const [masterpermission, setMasterpermission] = useState([]);

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token === null || token === undefined || token === '') {
            navigate('/login')
        }
        else {
            getmaternitycondition(page, perPage);
            const userdata = JSON.parse(localStorage.getItem('user'));
            const master_permission = userdata?.master_permission?.[0] || {};
            setMasterpermission(master_permission);
        }
    }, [])

   const [maternitycondition, setMaternitycondition] = useState('');
    const [details, setDetails] = useState([]);


    const getmaternitycondition = (page, perPage) => {
        setData([]);
        const requestOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
        };
        fetch(`http://localhost:8000/api/maternity?limit=${perPage}&page=${page}`, requestOptions)
            .then(response => response.json())
            .then(
                data => {
                    const total = data.count;
                    const slice = total / perPage;
                    const pages = Math.ceil(slice);
                    setPageCount(pages);
                    const list = data.data;
                    setData(list)
                }
            );
    }

    console.log(data)

    const fileType = 'xlsx'
    const exporttocsv = () => {
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
        const excelBuffer = XLSX.write(wb, { booktype: "xlsx", type: "array" });
        const newdata = new Blob([excelBuffer], { type: fileType });
        FileSaver.saveAs(newdata, "User-type" + ".xlsx")
    }

    const handlePageClick = (e) => {
        const selectedPage = e.selected;
        setPage(selectedPage + 1);
        getmaternitycondition(selectedPage + 1, perPage);
    };


    const updatestatus = async (id, status) => {

        let result = await fetch(`http://localhost:8000/api/maternity?id=${id}`, {
            method: 'put',
            body: JSON.stringify({ status: status }),
            headers: {
                'Content-Type': 'application/json',
            },
        })
        result = await result.json();
        swal("Updated Succesfully", "", "success");
        getmaternitycondition(page, perPage)
    }

    const collectExceldata = async (e) => {
        e.preventDefault()
        const fd = new FormData()
        fd.append('file', excelfile)
        let result = await fetch("https://lmpapi.handsintechnology.in/api/read_user_type_excel ",
            {
                method: "post",
                body: fd,
            })
            .then(response => response.json())
            .then(data => {
                if (data.status == 200) {
                    setVisible(!visible)
                    swal({
                        title: "Wow!",
                        text: data.message,
                        type: "success",
                        icon: "success"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
                else {
                    setVisible(!visible)
                    swal({
                        title: "Error!",
                        text: data.message,
                        type: "error",
                        icon: "error"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
            });
    }


    const addmaternitycondition = async (e) => {
        e.preventDefault();

        await fetch('http://localhost:8000/api/maternity', {
            method: 'post',
            body: JSON.stringify({ condition : maternitycondition}),
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.status == 201) {
                    setShowModal(false);
                    swal({
                        title: "Wow!",
                        text: data.message,
                        type: "success",
                        icon: "success"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
                else {
                    setShowModal(false);
                    swal({
                        title: "Error!",
                        text: data.message,
                        type: "error",
                        icon: "error"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
            });
    }


    const getdetails = async (ParamValue) => {
        setId(ParamValue)
        let result = await fetch(`http://localhost:8000/api/maternityById?id=${ParamValue}`, {
            method: 'get',
        })

        result = await result.json();
        setDetails(result.data);
        setVisibleedit(true);

    }
    console.log(details)


const [editmaternitycondition, setEdittermscondition] = useState('');

    const updatematernityconditions = async (e) => {
        e.preventDefault();

        console.log(id)
        console.log(editmaternitycondition)

        await fetch(`http://localhost:8000/api/maternity?id=${id}`, {
            method: 'put',
            body: JSON.stringify(
                {
                    condition: editmaternitycondition,
                }
            ),
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.status == 200) {
                    setVisibleedit(false)
                    swal({
                        title: "Wow!",
                        text: data.message,
                        type: "success",
                        icon: "success"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
                else {
                    setVisibleedit(false)
                    swal({
                        title: "Error!",
                        text: data.message,
                        type: "error",
                        icon: "error"
                    }).then(function () {
                        getmaternitycondition(page, perPage);
                    });
                }
            });
    }


    const startFrom = (page - 1) * perPage;

    return (
        <>
            <Container>
                <div className="card mb-4">
                    <div className="card-header">
                        <div className="row">
                            <div className="col-md-6">
                                <h4 className="card-title">Maternity Conditions</h4>
                            </div>
                            <div className="col-md-6">
                                {masterpermission.usertype?.includes('create') ?
                                    <button className='btn btn-primary' style={{ float: "right" }} onClick={() => setShowModal(true)}>Add Maternity Conditions</button>
                                    : ''}
                            </div>
                        </div>
                    </div>
                    {/* <div className="card-header" style={{ textAlign: 'right' }}>
            { masterpermission.usertype?.includes('download') ?
            <a className="btn btn-dark btn-sm btn-icon-text m-r-10" style={{ backgroundColor: "green", marginRight: '15px' }} href={filePath} download><i className="fa fa-cloud-download" aria-hidden="true"></i> Download Sample File</a>
            : '' }
            { masterpermission.usertype?.includes('upload') ?
            <button className="btn btn-dark btn-sm btn-icon-text m-r-10" style={{ backgroundColor: "green", marginRight: '15px' }} onClick={() => setVisible(!visible)}><i className="fa fa-file-excel" aria-hidden="true"></i> Upload Excel</button>
            : '' }
            { masterpermission.usertype?.includes('export') ?
            <button className="btn btn-dark btn-sm btn-icon-text m-r-10" style={{ backgroundColor: "green" }} onClick={exporttocsv}><i className="fa fa-file-excel" aria-hidden="true"></i> Export Data to excel</button>
            : '' }
          </div> */}
                    <div className="card-body">
                        <table className="table table-bordered">
                            <thead className="thead-dark">
                                <tr className="table-info">
                                    <th scope="col">#</th>
                                    {/* <th scope="col">userId</th> */}
                                    <th scope="col">condition</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    data?.length > 0 ?
                                        data.map((item, index) =>
                                            <tr key={index}>
                                                <td>{startFrom + index + 1}</td>
                                                {/* <td>{item.userId}</td> */}
                                                <td>{item.condition}</td>
                                                <td>{item.status == 1 ? 'Active' : 'Inactive'}</td>
                                                {/* <td>{new Date(item.startDate).toLocaleString()}</td> */}
                                                <td>
                                                    {masterpermission.usertype?.includes('edit') && (
                                                        <button className="btn btn-primary" onClick={() => getdetails(item._id)}>Edit</button>
                                                    )}
                                                    {' '}
                                                    {masterpermission.usertype?.includes('delete') && (
                                                        <>
                                                            {
                                                                item.status === 1 ?
                                                                    <button className="btn btn-danger" onClick={() => { if (window.confirm('Are you sure you wish to deactivate this item?')) updatestatus(item._id, 0) }}>Deactivate</button> :
                                                                    <button className="btn btn-success" onClick={() => { if (window.confirm('Are you sure you wish to activate this item?')) updatestatus(item._id, 1) }}>Activate</button>
                                                            }
                                                        </>
                                                    )}
                                                </td>
                                            </tr>
                                        ) : <tr>
                                            <td colSpan="6">No Data Found</td>
                                        </tr>
                                }
                            </tbody>
                        </table>
                        <ReactPaginate
                            previousLabel={"Previous"}
                            nextLabel={"Next"}
                            breakLabel={"..."}
                            pageCount={pageCount}
                            marginPagesDisplayed={2}
                            pageRangeDisplayed={3}
                            onPageChange={handlePageClick}
                            containerClassName={"pagination justify-content-end"}
                            pageClassName={"page-item"}
                            pageLinkClassName={"page-link"}
                            previousClassName={"page-item"}
                            previousLinkClassName={"page-link"}
                            nextClassName={"page-item"}
                            nextLinkClassName={"page-link"}
                            breakClassName={"page-item"}
                            breakLinkClassName={"page-link"}
                            activeClassName={"active"}
                        />
                    </div>
                </div>

            </Container>
            <CModal alignment="center" visible={visible} onClose={() => setVisible(false)}>
                <CModalHeader onClose={() => setVisible(false)}>
                    <CModalTitle>Upload Excel File</CModalTitle>
                </CModalHeader>
                <CModalBody>
                    <div >
                        {/* <label className="form-label"><strong>Upload Excel File</strong></label> */}
                        <input type="file" className="form-control" id="DHA" defaultValue="" required
                            onChange={(e) => setExcelfile(e.target.files[0])} />
                    </div>

                </CModalBody>
                <CModalFooter>
                    <CButton color="secondary" onClick={() => setVisible(false)}>
                        Close
                    </CButton>
                    <CButton color="primary" onClick={collectExceldata} href={'/Viewtraveltype'}>Upload</CButton>
                </CModalFooter>
            </CModal>

            <Modal size='lg' show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Add Maternity Conditions</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card">

                                    <div className="card-body">
                                        <form>
                                            <div className="row">

                                                <div className="col-md-6">
                                                    <label className="form-label"><strong>Add Maternity Condition</strong></label>
                                               
                                                    <textarea className="form-control" rows="3" cols="10" name="terms_constions" placeholder="Enter Maternity Condition" onChange={(e) => setMaternitycondition(e.target.value)} />
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <button type="submit" className="btn btn-primary mt-2 submit_all" style={{ float: "right" }} onClick={addmaternitycondition}>Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal size='lg' show={visibleedit} onHide={() => setVisibleedit(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Terms & Conditions</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card">
                                    <div className="card-body">
                                        <form >
                                        
                                            <div className="row">
                                                    <div className="col-md-6">
                                                        <label className="form-label"><strong>Edit Terms & Condition</strong></label>
                                                        <textarea className="form-control" rows="3" name="terms_constions" placeholder="Enter Terms & Condition" defaultValue={details.condition} onChange={(e) => setEdittermscondition(e.target.value)}/>
                                                        </div>

                                            </div>
                                        
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <button type="submit" className="btn btn-primary mt-2 submit_all" style={{ float: "right" }} onClick={updatematernityconditions}>Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setVisibleedit(false)}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default Maternitycondition;